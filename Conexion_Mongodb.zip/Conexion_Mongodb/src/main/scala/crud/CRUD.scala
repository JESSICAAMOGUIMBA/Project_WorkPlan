package crud
import scala.concurrent.{ExecutionContext, Future}
import reactivemongo.api.{AsyncDriver, Cursor, DefaultDB, MongoConnection}
import reactivemongo.bson.{BSONDocument, BSONDocumentReader, BSONDocumentWriter, Macros}
import reactivemongo.api.MongoConnection
import reactivemongo.api.commands.WriteResult

import scala.util.{Failure, Success}

//App para aplicaciones de escritorio (Clase principal)
object CRUD extends  App {


  // My settings (see available connection options)
  val mongoUri = "mongodb://localhost:27017/mydb" //crea una bdd

  import ExecutionContext.Implicits.global // use any appropriate context  //importa un contexto de ejecucion
  // para saber cual es el hilo principal de la ejecucion (Implicits)va a estar presente en tod0
  println("Ejecicion 1")
  // Connect to the database: Must be done only once per application
  val driver = AsyncDriver()//driverAsincronico
  val parsedUri = Future.fromTry(MongoConnection parseURI mongoUri) //Future.fromTry

  // Database and collections: Get references
  val futureConnection = parsedUri.flatMap(driver.connect(_))
  def db1: Future[DefaultDB] = futureConnection.flatMap(_.database("conexionDB"))//creacion de BDD
  def db2: Future[DefaultDB] = futureConnection.flatMap(_.database("anotherdb"))//creacion de BDD
  def personCollection = db1.map(_.collection("person"))//creacion de una coleccion a partir de la BDD

  // Write Documents: insert or update

  implicit def personWriter: BSONDocumentWriter[Person] = Macros.writer[Person]
  // or provide a custom one
  println("Ejecucion 2")

  // use personWriter
  def createPerson(person: Person): Future[Unit] =
    personCollection.flatMap(_.insert.one(person).map(result=> println(result)))

  def updatePerson(person: Person): Future[Int] = {
    val selector = BSONDocument(
      "firstName" -> person.firstName,
      "lastName" -> person.lastName
    )

    // Update the matching person
    personCollection.flatMap(_.update.one(selector, person).map(_.n))
  }

  implicit def personReader: BSONDocumentReader[Person] = Macros.reader[Person]
  // or provide a custom one

  def findPersonByAge(age: Int): Future[List[Person]] =
    personCollection.flatMap(_.find(BSONDocument("age" -> age)). // query builder
      cursor[Person](). // using the result cursor
      collect[List](-1, Cursor.FailOnError[List[Person]]()))
  // ... deserializes the document using personReader

  /*--------------*/


/*
  def deletePerson(person: Person): Future[String] = {
     val selector = BSONDocument(
      "email" -> person.email
     )
     personCollection.flatMap(_.delete.one(selector, person).map(_.n))//en esta linea me salie un error el cual no hallo la forma de sustituir "n" para que no devuelva enteros
  }
   //deletePerson(person1)

 */
  // Custom persistent types
  case class Person(firstName: String, lastName: String, age: Int, email:String)
  //crear personas
  val person1 = Person("Ana","Alban",18,"ana.alban@gmail.com")
  val person2 = Person("Ana","Alban",20,"alban@gmail.com")
  val person3 = Person("Ramiro","Moran",25,"ramiro.moran@gmail.com")
  val person4 = Person("Alex","Romo",22,"alex.romo@gmail.com")

  //Llamado a la funcion para crear  persons en la db1
  createPerson(person1)
  createPerson(person2)
  //createPerson(person3)
  //createPerson(person4)

  //update, no borra solo sustituye

  updatePerson(person3)

  //guarde la lista en "personas" hice un filtro para que busque por el email, edad  e imprima
  val personas = List.apply(person1,person2,person3,person4)
    personas.filter(_.email == "alban@gmail.com")
      .filter(_.age > 25).map(_.firstName)
    println("---------------------------")
    println("       "+personas)
    println("---------------------------")


}
